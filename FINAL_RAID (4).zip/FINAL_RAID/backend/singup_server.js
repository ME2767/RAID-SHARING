const express = require("express");
const mysql = require("mysql");
const bodyParser = require("body-parser");
const bcrypt = require("bcryptjs");
const cors = require("cors");
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors()); // Enable CORS

// MySQL connection setup
const db = mysql.createConnection({
  host: "localhost",
  user: "root", // Replace with your MySQL username
  password: "eswarASM143!", // Replace with your MySQL password
  database: "userdb" // The name of your database
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL: ", err);
    process.exit(1); // Exit the process if MySQL connection fails
  }
  console.log("Connected to MySQL.");
});

// Sign-up route
app.post("/signup", (req, res) => {
  const { username, email, password } = req.body;

  console.log('Received signup request with data:', { username, email, password });

  // Validate inputs
  if (!username || !email || !password) {
    return res.status(400).json({
      success: false,
      message: "Please provide username, email, and password"
    });
  }

  // Hash the password before saving
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      console.error("Error hashing password: ", err);
      return res.status(500).json({ success: false, message: "Error signing up" });
    }

    const query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    db.query(query, [username, email, hashedPassword], (err, result) => {
      if (err) {
        console.error("Error inserting user data: ", err);
        return res.status(500).json({ success: false, message: "Error signing up" });
      }
      console.log("User signed up successfully:", result);
      res.status(200).json({ success: true, message: "User signed up successfully" });
    });
  });
});

// Login route
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  // Validate inputs
  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: "Please provide email and password"
    });
  }

  const query = "SELECT * FROM users WHERE email = ?";
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error("Error querying user data: ", err);
      return res.status(500).json({ success: false, message: "Error logging in" });
    }

    if (results.length > 0) {
      const user = results[0];

      // Compare hashed password
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          console.error("Error comparing passwords: ", err);
          return res.status(500).json({ success: false, message: "Error logging in" });
        }

        if (isMatch) {
          return res.status(200).json({ success: true, message: "Login successful" });
        } else {
          return res.status(401).json({ success: false, message: "Invalid password" });
        }
      });
    } else {
      return res.status(404).json({ success: false, message: "User not found" });
    }
  });
});

// Gracefully shut down the MySQL connection when the app stops
process.on("SIGINT", () => {
  db.end((err) => {
    if (err) {
      console.log("Error closing MySQL connection: ", err);
    }
    console.log("MySQL connection closed.");
    process.exit(0); // Exit the process
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
