document.addEventListener("DOMContentLoaded", () => {
    fetch("http://localhost:5000/getUser", {
        credentials: "include" // Important to maintain session
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById("welcome").innerText = `Welcome, ${data.user.name}`;
            document.getElementById("email").innerText = `Email: ${data.user.email}`;
        } else {
            document.getElementById("welcome").innerText = "User not logged in";
        }
    })
    .catch(err => console.error("Error fetching user:", err));
});
